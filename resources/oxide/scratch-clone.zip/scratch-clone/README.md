# Scratch clone

Second coursework for CS141.
