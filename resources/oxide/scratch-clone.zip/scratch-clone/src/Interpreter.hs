--------------------------------------------------------------------------------
-- Functional Programming (CS141)                                             --
-- Coursework 2: Scratch clone                                                --
--------------------------------------------------------------------------------

module Interpreter where

--------------------------------------------------------------------------------

import Language

import Data.Maybe ( isNothing )

--------------------------------------------------------------------------------

-- | In our memory, variables and functions are stored seperately
type Memory = (VMemory, FMemory)

-- | FMemory and VMemory maps named locations to functions and variable values, respectively
type VMemory = [(String, Int)]
type FMemory = [(String, (Program, Maybe Expr, [String]))]

-- | Enumerates reasons for errors.
data Err
    = DivByZeroError                    -- ^ Division by zero was attempted.
    | NegativeExponentError             -- ^ Raising a number to a negative
                                        -- exponent was attempted.
    | UninitialisedMemory String        -- ^ Tried to read from a variable
                                        -- that does not exist.
    | UndefinedFunction String          -- ^ Tried to call a function that
                                        -- has not been defined
    | IllegalReturnExpression String    -- ^ Tried to evaluate a function
                                        -- that has no return expression
    deriving (Eq, Show)

--------------------------------------------------------------------------------

-- EXTENSION!
-- I have implemented functions.
-- NOTE: the return _ if _ block is present in blockly, but I have made no effort to
--  implement it!

-- | Given a program and the initial memory contents, determines
-- what evaluating the program does to the memory.
interpret :: Program -> VMemory -> Either Err Memory
interpret ss vmem = interpret' ss (vmem, [])

-- Interpret' exists so that interpret can still be called with the new Memory
-- object, since interpret now has to return VMemory.
interpret' :: Program -> Memory -> Either Err Memory
interpret' [] mem = Right mem
interpret' (statement:statements) mem = interpretStmt statement mem >>= interpret' statements


interpretStmt :: Stmt -> Memory -> Either Err Memory
interpretStmt (AssignStmt avar aexpr) mem@(vmem, fmem) = do -- pattern match to split memory into vmem and fmem
    (evaled, _) <- evalExpr aexpr mem --modified match to adapt new memory format
    Right ((avar, (snd.head) evaled ) : filter (\x -> fst x /= avar) vmem, fmem) -- modified filters to work around new memory

interpretStmt (IfStmt cond ifbody elif elsebody) mem = do
    (eCond, _) <- evalExpr cond mem
    if snd(head eCond) /= 0 then interpret' ifbody mem --if cond evaluates to true
    else if (not.null) elif then interpretStmt (IfStmt aCond aBody elifs elsebody) mem -- else, if there are elif clauses
    else interpret' elsebody mem where ((aCond, aBody):elifs) = elif -- else

interpretStmt (RepeatStmt texpr body) mem = do
    (t, _) <- evalExpr texpr mem
    loop ((snd.head) t) body mem where
        loop 0 _ mem' = Right mem'
        loop times ps mem' = interpret' ps mem' >>= loop (abs times - 1) ps

interpretStmt (CallNoReStmt fargs fname) (vmem, fmem) = case lookup fname fmem of
    Nothing -> Left (UndefinedFunction fname)
    Just (fbody, _, argVars) -> do -- if function is defined
        let newVMems = zip argVars fargs --put together variable names and values
        -- ++ used, since newVMems may have multiple elements
        let vmem' = newVMems ++ filter (\x -> isNothing $ lookup (fst x) newVMems) vmem -- check if already in newVMems, filter out
        --now memory has been added to with parameter values, interpret with new values in vmem'
        interpret' fbody (vmem', fmem)

interpretStmt (DefNoReStmt argnames fname ps) (vmem, fmem) = 
    Right (vmem, (fname, (ps, Nothing, argnames)) : filter (\x -> fst x /= fname) fmem)

interpretStmt (DefReStmt argnames fname ps retExpr) (vmem, fmem) = 
    Right (vmem, (fname, (ps, Just retExpr, argnames)) : filter (\x -> fst x /= fname) fmem)

--evaluation helper

evalExpr :: Expr -> Memory -> Either Err Memory
evalExpr (ValE x) _ = Right ([("", x)], [])
evalExpr (VarE x) ([], _) = Left (UninitialisedMemory x) -- may be unnessecary?
evalExpr (VarE x) (vmem, _) = case lookup x vmem of
    Nothing -> Left (UninitialisedMemory x)
    Just y -> Right ([(x, y)], [])

evalExpr (BinOpE op aExpr bExpr) mem = do
    (aEval, _) <- evalExpr aExpr mem
    (bEval, _) <- evalExpr bExpr mem
    let [(_, bNum)] = bEval
    case op of
        Add -> vmemOp (+) aEval bEval
        Sub -> vmemOp (-) aEval bEval
        Mul -> vmemOp (*) aEval bEval
        Equal -> vmemOpBool (==) aEval bEval
        Neq -> vmemOpBool (/=) aEval bEval
        LessThan -> vmemOpBool (<) aEval bEval
        LessOrEqual -> vmemOpBool (<=) aEval bEval
        GreaterThan -> vmemOpBool (>) aEval bEval
        GreaterOrEqual  -> vmemOpBool (>=) aEval bEval
        Div -> if bNum == 0 then Left DivByZeroError else vmemOp div aEval bEval
        Pow -> if bNum < 0 then Left NegativeExponentError else vmemOp (^) aEval bEval
        where vmemOp f [(_, aval)] [(_, bval)] = Right ([("", f aval bval)], [])
              vmemOp _ _ _ = undefined
              vmemOpBool f [(_, aval)] [(_, bval)] = Right ([("", if f aval bval then 1 else 0)], [])
              vmemOpBool _ _ _ = undefined

evalExpr (FuncE fargs fname) (vmem, fmem) = case lookup fname fmem of
    Nothing -> Left (UndefinedFunction fname)
    Just fToInterpret@(_, _, argVars) -> do
        let newVMems = zip argVars fargs -- also used in CallNoReStmt
        let vmem' = newVMems ++ filter (\x -> isNothing $ lookup (fst x) newVMems) vmem-- also used in CallNoReStmt
        mem' <- interpret' (fst3 fToInterpret) (vmem', fmem) -- interpret with newly modified memory
        -- maybe saves pattern matching - default to illegalExpression, unless it can be found, where is is assigned to retExpr
        retExpr <- maybe (Left (IllegalReturnExpression fname)) Right (snd3 fToInterpret) 
        evalExpr retExpr mem' where
            -- FMemory is now a triplet, but still need to get 1st and 2nd elements
            fst3 (a, _, _) = a
            snd3 (_, b, _) = b

-- Alternative implementation:
{-
evalExpr (FuncE fname) mem@(_, fmem) = do
    case lookup fname fmem of
        Nothing -> Left (UndefinedFunction fname)
        Just y -> case interpret' (fst y) mem of
            Left err -> Left err
            Right mem' -> case snd y of
                Just retStmt -> evalExpr retStmt mem'
                Nothing -> Right mem' -}

--------------------------------------------------------------------------------