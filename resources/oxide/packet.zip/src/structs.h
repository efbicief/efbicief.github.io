#ifndef STRUCTS_H
#define STRUCTS_H

#include <pcap.h>

enum pkt_type {
    // Type of packet, as to be determined by analysis.c
    PKT_SYN,
    PKT_ARP,
    PKT_BLIST,
    PKT_OK,
};

struct analysis_result {
    enum pkt_type type;
    char (*src_ip)[INET_ADDRSTRLEN];
};

struct packet_info {
    const struct pcap_pkthdr* pkt_header;
    const unsigned char* pkt_data;
};

struct queue_node {
    void* data;
    struct queue_node* behind;
};

struct queue {
    int length;
    struct queue_node* head;
    struct queue_node* tail;
};

#endif