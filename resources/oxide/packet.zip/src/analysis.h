#ifndef CS241_ANALYSIS_H
#define CS241_ANALYSIS_H

#include <pcap.h>
//#include "structs.h"

struct analysis_result* analyse(const struct pcap_pkthdr *header,
            const unsigned char *packet);

#endif
