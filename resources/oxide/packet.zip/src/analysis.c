#include "analysis.h"

#include <pcap.h>
#include <netinet/if_ether.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/if_ether.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>

#include "structs.h"

#define MAX_HNAME_LEN 100
#define PORT_HTTP 80

char* find_hostname(const unsigned char* data) {
  // If get request
  if (data[0] == 'G' && data[1] == 'E' && data[2] == 'T') {
    int i;
    int hn_found = 0;
    char* hostname = calloc(MAX_HNAME_LEN, sizeof(char));
    hostname[0] = '\0';
    for (i=0; i<MAX_HNAME_LEN; i++) {
      if (data[i] > 31 && data[i] < 127) {

        // Search through packet info until "Host: " found
        if (data[i] == 'H' && data[i+1] == 'o' && data[i+2] == 's' && data[i+3] == 't' && data[i+4] == ':' && data[i+5] == ' ') {
          hn_found = 1;
          int j;
          for (j=i+6; j<MAX_HNAME_LEN+i+5; j++) {

            // Hostname is remainder of data until '\r'
            if (data[j] == '\r') {
              hostname[j-(i+6)] = '\0';
              break;
            } else {
              hostname[j-(i+6)] = data[j];
            }
          }
        }
      }
    }

    if (hn_found) {
      return hostname;
    }
  }
  return NULL;
}

struct analysis_result* analyse(const struct pcap_pkthdr *header,
             const unsigned char *packet) {
  
  // cast structs for headers
  struct ether_header *eth_header = (struct ether_header *) packet;
  struct ip* ip_header = (struct ip *) (packet + ETH_HLEN);
  struct tcphdr* tcp_header = (struct tcphdr *) (packet + ETH_HLEN + ip_header->ip_hl*4);
  const unsigned char* pkt_data = packet + ETH_HLEN + ip_header->ip_hl*4 + tcp_header->th_off*4;

  // Get source and destination IP address of packet
  char src_ip[INET_ADDRSTRLEN];
  char dst_ip[INET_ADDRSTRLEN];
  inet_ntop(AF_INET, &ip_header->ip_src, src_ip, INET_ADDRSTRLEN);
  inet_ntop(AF_INET, &ip_header->ip_dst, dst_ip, INET_ADDRSTRLEN);

  // Construct result struct to return 
  struct analysis_result* result = malloc(sizeof(struct analysis_result));
  result->src_ip = &src_ip;

  // SYN packet detection
  if (tcp_header->syn) {
    result->type = PKT_SYN;
    return result;
  }

  // ARP packet detection
  if (ntohs(eth_header->ether_type) == ETHERTYPE_ARP) {
    result->type = PKT_ARP;
    return result;
  }

  // blacklist detection
  uint16_t dest_port = ntohs(tcp_header->th_dport);

  if (dest_port == PORT_HTTP) { // dest_port before changes
    char* hostname = find_hostname(pkt_data);
    if (hostname != NULL && (strcmp(hostname, "www.google.co.uk") == 0 || strcmp(hostname, "www.bbc.com") == 0)) {
      free(hostname);
      printf("===Blacklist Violation===\nSource address: %s\nDestination address: %s\n\n", src_ip, dst_ip);
      result->type = PKT_BLIST;
      return result;
    }
    free(hostname);
  }

  // If none of the above, return OK.
  result->type = PKT_OK;
  return result;
}
