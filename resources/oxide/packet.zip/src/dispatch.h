#ifndef CS241_DISPATCH_H
#define CS241_DISPATCH_H

#include <pcap.h>

void instantiate_thread_pool();

void* queue_analysis_thread(void* arg);

void dispatch(const struct pcap_pkthdr *header, 
              const unsigned char *packet);

char* generate_report();

#endif
