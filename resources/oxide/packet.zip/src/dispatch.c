#include "dispatch.h"

#include <pcap.h>
#include <pthread.h>
#include <stdlib.h>
#include <string.h>

#include "structs.h"
#include "analysis.h"

#define NUM_OF_WORKERS 16
#define REPORT_BUF_SIZE 255

static struct queue pqueue, ip_list;

static pthread_t* threads;
static pthread_mutex_t queue_lock, ips_lock, sum_lock;

static int end_threads;
static int* sums;

void instantiate_thread_pool() {
  // Instantiate packet queue
  pqueue.length = 0;
  pqueue.head = NULL;
  pqueue.tail = NULL;

  // Instantiate ip list queue
  ip_list.length = 0;
  ip_list.head = NULL;
  ip_list.tail = NULL;

  // Instantiate mutex locks
  pthread_mutex_init(&queue_lock, NULL);
  pthread_mutex_init(&ips_lock, NULL);
  pthread_mutex_init(&sum_lock, NULL);

  // Instantiate thread killing mechanism
  end_threads = 0;

  // Instantiate packet type sums
  sums = calloc(3, sizeof(int));

  // Create and populate thread pool
  threads = malloc(NUM_OF_WORKERS * sizeof(pthread_t));
  int i;
  for (i=0; i<NUM_OF_WORKERS; i++) {
      pthread_create(&threads[i], NULL, queue_analysis_thread, NULL); // leak?
      pthread_detach(threads[i]);
  }
}

void enqueue_packet(struct packet_info* this_packet) {
  struct queue_node* this_node = malloc(sizeof(struct queue_node));

  this_node->data = this_packet;
  this_node->behind = NULL;

  pthread_mutex_lock(&queue_lock);

  // If queue empty, set to head
  if (pqueue.length == 0) {
    pqueue.head = this_node;
  // If length = 1, there may be no tail, therefore set head's behind
  } else if (pqueue.length == 1) {
    pqueue.head->behind = this_node;
  // If length > 1, there will be a tail
  } else {
    pqueue.tail->behind = this_node;
  }
  pqueue.tail = this_node;
  pqueue.length++;

  pthread_mutex_unlock(&queue_lock);
}

struct packet_info* dequeue_packet() {
  pthread_mutex_lock(&queue_lock);
  if (pqueue.length > 0) {
    // Actually dequeue
    struct packet_info* this_packet = pqueue.head->data;
    struct queue_node* old_head = pqueue.head;
    pqueue.head = old_head->behind;
    free(old_head);
    pqueue.length--;
    pthread_mutex_unlock(&queue_lock);
    return this_packet;
  } else {
    // Do not dequeue - it is empty
    pthread_mutex_unlock(&queue_lock);
    return NULL;
  }
}

void enqueue_ip_no_dup(char* ip_addr) {
  struct queue_node* new_node = malloc(sizeof(struct queue_node));
  new_node->data = ip_addr; // remove (void *)?
  new_node->behind = NULL;

  pthread_mutex_lock(&ips_lock);

  // See if already in queue
  int is_dup = 0;
  struct queue_node* curr_node = ip_list.head;

  // If queue empty, set to head
  if (ip_list.length == 0) {
    ip_list.head = new_node;
    ip_list.tail = new_node;
    ip_list.length++;
  } else {

    // Linear search through linked list
    while (curr_node != NULL) {
      // NOTE: memcmp may throw "Conditional jump or move depends on uninitialised value"
      // in valgrind - this is due to a cast to (void *) and is a false positive, since 
      // only sizeof(char) * INET_ADDRSTRLEN bytes are ebing compared, which will never
      // fall into an undefined region, therefore behaviour is always defined
      if (memcmp(new_node->data, curr_node->data, sizeof(char) * INET_ADDRSTRLEN) == 0) {
        is_dup = 1;
      }
      curr_node = curr_node->behind;
    }

    // If not a duplicate, add to ip list
    if (!is_dup) {
      ip_list.tail->behind = new_node;
      ip_list.tail = new_node;
      ip_list.length++;
    } else {
      free(new_node->data);
      free(new_node);
    }
  }
  pthread_mutex_unlock(&ips_lock);
}

void* queue_analysis_thread(void* arg) {
  // Keep going until told to stop
  while(!end_threads) {
    if (pqueue.length > 0) {

      // Send packet info to analyse
      struct packet_info* to_analyse = dequeue_packet();
      struct analysis_result* analysis_result = analyse(to_analyse->pkt_header, to_analyse->pkt_data);
      free(to_analyse);

      // Add to sum count if packet type is significant
      if (analysis_result->type != PKT_OK) {
        pthread_mutex_lock(&sum_lock);
        sums[analysis_result->type]++;
        pthread_mutex_unlock(&sum_lock);

        // If SYN, track IP address
        if (analysis_result->type == PKT_SYN) {
          char* ip = *(analysis_result->src_ip);
          char* new_ip_str = malloc(sizeof(char) * INET_ADDRSTRLEN);
          memcpy(new_ip_str, ip, sizeof(char) * INET_ADDRSTRLEN);
          enqueue_ip_no_dup(new_ip_str);
        }
      }
      free(analysis_result);
    }
  }
  end_threads++;
  return NULL;
}

void dispatch(const struct pcap_pkthdr *header,
              const unsigned char *packet
              ){
  
  // Create packet struct to enqueue
  struct packet_info* new_packet = malloc(sizeof(struct packet_info));
  new_packet->pkt_header = header;
  new_packet->pkt_data = packet;

  enqueue_packet(new_packet);
}

char* generate_report() {
  // Terminate threads
  end_threads = 1;

  // When program terminated, generate report
  char* report = (char *) calloc(REPORT_BUF_SIZE, sizeof(char));
  snprintf(report, REPORT_BUF_SIZE, "\nIntrusion Detection Report:\n"
                                    "%d SYN packets detected from %d different IPs (syn attack)\n"
                                    "%d ARP responses (cache poisoning)\n"
                                    "%d URL Blacklist violations\n",
                                    sums[PKT_SYN],ip_list.length,sums[PKT_ARP],sums[PKT_BLIST]);
  
  // Do some cleaning up to avoid memory leakage
  // Free ip queue
  struct queue_node* prev_node;
  struct queue_node* this_node = ip_list.head;
  while (this_node != NULL) {
    prev_node = this_node;
    this_node = this_node->behind;
    free(prev_node->data);
    free(prev_node);
  }

  // Free statics
  free(threads);
  free(sums);
  pthread_mutex_destroy(&queue_lock);
  pthread_mutex_destroy(&ips_lock);
  pthread_mutex_destroy(&sum_lock);
  
  // Wait for all threads to terminate before returning
  while (end_threads < 1 + NUM_OF_WORKERS) {
    continue;
  }

  return report;
}
