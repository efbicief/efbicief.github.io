#ifndef COMPUTE_RESIDUAL_H
#define COMPUTE_RESIDUAL_H
int compute_residual(const int n, const float * const v1, const float * const v2, double * const residual);
#endif
