#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <math.h>
#include <omp.h>
#include <immintrin.h>

#include "sparsemv.h"

#define LOOPFACTOR 8

// https://stackoverflow.com/questions/13219146/how-to-sum-m256-horizontally
inline float hsum_float_avx(__m256 x) {
    const __m128 hiQuad = _mm256_extractf128_ps(x, 1); // hiQuad = ( x7, x6, x5, x4 )
    const __m128 loQuad = _mm256_castps256_ps128(x); // loQuad = ( x3, x2, x1, x0 )
    const __m128 sumQuad = _mm_add_ps(loQuad, hiQuad); // sumQuad = ( x3 + x7, x2 + x6, x1 + x5, x0 + x4 )
    const __m128 loDual = sumQuad; // loDual = ( -, -, x1 + x5, x0 + x4 )
    const __m128 hiDual = _mm_movehl_ps(sumQuad, sumQuad); // hiDual = ( -, -, x3 + x7, x2 + x6 )
    const __m128 sumDual = _mm_add_ps(loDual, hiDual); // sumDual = ( -, -, x1 + x3 + x5 + x7, x0 + x2 + x4 + x6 )
    const __m128 lo = sumDual; // lo = ( -, -, -, x0 + x2 + x4 + x6 )
    const __m128 hi = _mm_shuffle_ps(sumDual, sumDual, 0x1); // hi = ( -, -, -, x1 + x3 + x5 + x7 )
    const __m128 sum = _mm_add_ss(lo, hi); // sum = ( -, -, -, x0 + x1 + x2 + x3 + x4 + x5 + x6 + x7 )
    return _mm_cvtss_f32(sum);
}

/**
 * @brief Compute matrix vector product (y = A*x)
 * 
 * @param A Known matrix
 * @param x Known vector
 * @param y Return vector
 * @return int 0 if no error
 */
int sparsemv(struct mesh *A, const float * const x, float * const y)
{

  const int nrow = (const int) A->local_nrow;
  #pragma omp parallel for schedule(static)
  for (int i=0; i< nrow; i++) {
      float sum = 0.0;
      const float * const cur_vals = (const float * const) A->ptr_to_vals_in_row[i];
      const int * const cur_inds = (const int * const) A->ptr_to_inds_in_row[i];
      const int cur_nnz = (const int) A->nnz_in_row[i];

      int loopN = (cur_nnz/LOOPFACTOR)*LOOPFACTOR;

      // #pragma omp parallel for reduction (+:sum) // Double parallelisation is a bad idea!
      for (int j=0; j<loopN; j+=LOOPFACTOR) { 
        __m256 valsvec = _mm256_loadu_ps(cur_vals+j); // Load vectors with 8 floats
        __m256i indsvec = _mm256_loadu_si256((__m256i*) (cur_inds+j));
        __m256 xvec = _mm256_i32gather_ps(x, indsvec, 4); // Get values by indicies in indsvec
        float toAdd = hsum_float_avx(_mm256_mul_ps(valsvec, xvec)); // Sum values in xvec to add to sum
        sum += toAdd;
      }

      // Add rest that don't fill a vector unit sequentially
      for (int j=loopN; j< cur_nnz; j++) {
        sum += cur_vals[j]*x[cur_inds[j]];
      }

      y[i] = sum;
    }
  return 0;
}
