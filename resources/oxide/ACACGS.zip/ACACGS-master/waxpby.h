#ifndef WAXBY_H
#define WAXBY_H
int waxpby (const int n, const float alpha, const float * const x, const float beta, const float * const y, float * const w);
#endif
