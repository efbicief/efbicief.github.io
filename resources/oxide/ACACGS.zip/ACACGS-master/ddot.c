#include <immintrin.h>
#include <omp.h>
#include "ddot.h"

#define LOOPFACTOR 8

// https://stackoverflow.com/questions/49941645/get-sum-of-values-stored-in-m256d-with-sse-avx
inline double hsum_double_avx(__m256d v) {
    __m128d vlow  = _mm256_castpd256_pd128(v);
    __m128d vhigh = _mm256_extractf128_pd(v, 1); // high 128
            vlow  = _mm_add_pd(vlow, vhigh);     // reduce down to 128

    __m128d high64 = _mm_unpackhi_pd(vlow, vlow);
    return  _mm_cvtsd_f64(_mm_add_sd(vlow, high64));  // reduce to scalar
}

// https://stackoverflow.com/questions/13219146/how-to-sum-m256-horizontally
inline float hsum_float_avx(__m256 x) {
    const __m128 hiQuad = _mm256_extractf128_ps(x, 1); // hiQuad = ( x7, x6, x5, x4 )
    const __m128 loQuad = _mm256_castps256_ps128(x); // loQuad = ( x3, x2, x1, x0 )
    const __m128 sumQuad = _mm_add_ps(loQuad, hiQuad); // sumQuad = ( x3 + x7, x2 + x6, x1 + x5, x0 + x4 )
    const __m128 loDual = sumQuad; // loDual = ( -, -, x1 + x5, x0 + x4 )
    const __m128 hiDual = _mm_movehl_ps(sumQuad, sumQuad); // hiDual = ( -, -, x3 + x7, x2 + x6 )
    const __m128 sumDual = _mm_add_ps(loDual, hiDual); // sumDual = ( -, -, x1 + x3 + x5 + x7, x0 + x2 + x4 + x6 )
    const __m128 lo = sumDual; // lo = ( -, -, -, x0 + x2 + x4 + x6 )
    const __m128 hi = _mm_shuffle_ps(sumDual, sumDual, 0x1); // hi = ( -, -, -, x1 + x3 + x5 + x7 )
    const __m128 sum = _mm_add_ss(lo, hi); // sum = ( -, -, -, x0 + x1 + x2 + x3 + x4 + x5 + x6 + x7 )
    return _mm_cvtss_f32(sum);
}

/**
 * @brief Compute the dot product of two vectors
 * 
 * @param n Number of vector elements
 * @param x Input vector
 * @param y Input vector
 * @param result Pointer to scalar result value
 * @return int 0 if no error
 */
int ddot (const int n, const float * const x, const float * const y, float * const result) {  
  float local_result = 0.0;

  // Hand implemented AVX approach - provides ~2.17x speedup. Second loop was still used, replacing i=0 with i=loopN.

  // int loopN = (n/LOOPFACTOR)*LOOPFACTOR;
  // #pragma omp parallel for schedule(static) reduction (+:local_result) 
  // for (int i=0; i<loopN; i+=LOOPFACTOR) { // Race condition somewhere...
  //   __m256 xvec = _mm256_loadu_ps(x+i);
  //   __m256 yvec = _mm256_loadu_ps(y+i);
  //   local_result += hsum_float_avx(_mm256_mul_ps(xvec, yvec));
  // }

  // OpenMP SIMD/AVX approach - provides ~7.37x speedup
  #pragma omp parallel for simd schedule(static) reduction(+:local_result)
  for (int i=0; i<n; i++) {
    local_result += x[i]*y[i];
  }

  *result = local_result;

  return 0;
}
