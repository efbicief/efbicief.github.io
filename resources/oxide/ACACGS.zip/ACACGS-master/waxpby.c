#include <omp.h>
#include  <immintrin.h>
#include "waxpby.h"

#define LOOPFACTOR 8

/**
 * @brief Compute the update of a vector with the sum of two scaled vectors
 * 
 * @param n Number of vector elements
 * @param alpha Scalars applied to x
 * @param x Input vector
 * @param beta Scalars applied to y
 * @param y Input vector
 * @param w Output vector
 * @return int 0 if no error
 */
int waxpby (const int n, const float alpha, const float * const x, const float beta, const float * const y, float * const w) {  
  int i;

  // Hand implemented AVX approach - provides ~2.02x speedup. Second loop was still used, replacing i=0 with i=loopN.

  // __m256 alphavec = _mm256_set1_ps(alpha);
  // __m256 betavec = _mm256_set1_ps(beta);
  // int loopN = (n/LOOPFACTOR)*LOOPFACTOR;
  // #pragma omp parallel for schedule(static)
  // for (i=0; i<loopN; i+=LOOPFACTOR) { //note: consider loadu instead of load
  //   __m256 xvec = _mm256_load_ps(x+i);
  //   __m256 yvec = _mm256_load_ps(y+i);
  //   __m256 wvec = _mm256_add_ps(_mm256_mul_ps(alphavec, xvec), _mm256_mul_ps(betavec, yvec));
  //   _mm256_storeu_ps(w+i, wvec);
  // }

  // OpenMP SIMD/AVX approach - provides ~2.11x speedup
  #pragma omp parallel for simd schedule(static)
  for (i=0; i<n; i++) {
    w[i] = alpha * x[i] + beta * y[i];
  }

  return 0;
}
