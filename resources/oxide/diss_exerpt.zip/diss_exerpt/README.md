# Election simulation
Source for the CS351 project, Gerrymandering and Generation of Representative Electoral Boundaries.

# What's included?
- src: Source code for the main application.
- data: Python scripts for drawing graphs found in the dissertation. `main.rs` is the entry point.
- prototypes: Some different prototypes developed, as well as some data sources. None of these contain code that is relied upon by the main application.
- `database_dump.sql`: a backup of the database used in the project. It should be loaded before use, and failure to do so will result in the program not functioning.

# Running the code
0. Start a Postgres server by your preferred method. Load the database dumped in `database_dump.sql`. Configure line 4 of `pg_interface.rs` to connect to your Postgres server.
1. Install Rust with rustup. Instructions are [here](https://www.rust-lang.org/tools/install).
2. cd to this directory, and run `cargo run --release`
3. Congratulations, you are running the application!
Note that this has *only* been tested on an M1 (arm) Mac, so you may encounter issues when running on other platforms. Depending on your OS, you may require additional dependencies. You should look at any compile errors and install them in your preferred way. Particularly, you will require a C build chain to be installed on your system to compile `raylib`, which is a dependency of the application.
Postgres setup varies wildly by platform, so I am unfortunately unable to give instructions on how to do this.

# Controls
ENTER: Place 50 centroids.
SPACE: Start/stop simulation.
9, 0: Zoom in and out.
ARROW KEYS: Move around the map.
R: Reset everything.
ESC: Close application.

Note that once the application reaches iteration 50, it will pause as it changes from using the k-means method to the MCMC method. You must press SPACE a second time when this happens to continue.

Thank you!
