use std::collections::HashMap;

#[derive(Default, Clone, Debug)]
pub struct Coord {
  pub x: f64,
  pub y: f64,
  pub population: i32,
  pub cluster: i32,
  pub scale_factor: Option<f64>,
  pub constituency_name: Option<String>,
  pub oa_code: Option<String>,
}

struct Cluster {
  population_alpha: f64,
  scale_factor: Option<f64>,
}

fn calculate_distance(c1: &Coord, c2: &Coord) -> f64 {
  f64::sqrt((c1.x-c2.x).powi(2) + (c1.y-c2.y).powi(2))
}

// Calculate scale factors etc needed for weighted k-means
fn calculate_scale_factors(centroids: &Vec<Coord>, alpha: f64, beta: f64) -> Vec<Coord> {
  // calculate each pop ^ alpha, and sum them
  let mut total_pop_alpha: f64 = 0.0;
  let mut mod_clusters: HashMap<i32, Cluster> = HashMap::new();
  for cl in centroids {
    let pop_alpha = (cl.population as f64).powf(alpha);
    total_pop_alpha += pop_alpha;
    mod_clusters.insert(cl.cluster, Cluster {
      population_alpha: pop_alpha,
      scale_factor: cl.scale_factor,
    });
  }

  // calculate each scale factor
  for index_cl in &mut mod_clusters {
    let (_, cl) = index_cl;
    let weight = cl.population_alpha / total_pop_alpha;
    cl.scale_factor = Some(cl.scale_factor.unwrap_or(0.0)*beta + weight*(1.0-beta)); // as per spec
  }

  // Put new scale factors back into centroids
  let mut new_centroids: Vec<Coord> = Vec::new();
  for cr in centroids {
    new_centroids.push(Coord {
      x: cr.x,
      y: cr.y,
      population: cr.population,
      cluster: cr.cluster,
      scale_factor: match mod_clusters.get(&cr.cluster) {
        Some(cl) => cl.scale_factor,
        None => None,
      },
      constituency_name: None,
      oa_code: None,
    });
  }

  new_centroids
}

// implement k-means
pub fn iterate_grid(grid: &[Coord], centroids: &Vec<Coord>, alpha: f64, beta: f64) -> (Vec<Coord>, Vec<Coord>) {
  // Find closest centroid to each point, assign it to its' cluster
  let mut avg_count: HashMap<i32, (f64, f64, i32, i32)> = HashMap::new(); // cluster -> sumx, sumy so far, no. so far, pop. so far
  let mut cluster_scale_factors: HashMap<i32, Option<f64>> = HashMap::new(); // cluster -> scale factor
  centroids.iter().for_each(|ct| {
    cluster_scale_factors.insert(ct.cluster, ct.scale_factor);
  });

  // Calculate clusters
  let mut new_grid: Vec<Coord> = Vec::new();

  // for pt in &grid {
  grid.iter().for_each(|pt| {
    let mut min_dist = f64::MAX;
    let mut best_cluster = i32::MAX;
    for ct in centroids {
      // Actually do the weighted k-means
      let dist_kmeans = calculate_distance(&pt, &ct) * ct.scale_factor.unwrap_or(1.0);//.powf(1.8);
      if dist_kmeans < min_dist {
        min_dist = dist_kmeans;
        best_cluster = ct.cluster;
      }
    }

    // Add back into grid with cluster num
    new_grid.push(Coord {
      x: pt.x,
      y: pt.y,
      population: pt.population,
      cluster: best_cluster,
      scale_factor: None,
      constituency_name: pt.constituency_name.clone(),
      oa_code: pt.oa_code.clone(),
    });

    // Add to centroid sum
    match avg_count.get(&best_cluster) {
      Some((sumx, sumy, freqsofar, popsofar)) => {
        avg_count.insert(best_cluster, (sumx + pt.x, sumy + pt.y, freqsofar + 1, popsofar + pt.population));
      },
      None => {
        avg_count.insert(best_cluster, (pt.x, pt.y, 1, pt.population));
      },
    }
  });


  // Calculate new centroids
  let mut new_centroids: Vec<Coord> = Vec::new();
  for (cl, (x_sum, y_sum, freq, pop)) in avg_count {
    new_centroids.push(Coord {
      x: x_sum / freq as f64,
      y: y_sum / freq as f64,
      population: pop,
      cluster: cl,
      scale_factor: match cluster_scale_factors.get(&cl) {
        Some(sf) => *sf,
        None => None,
      },
      constituency_name: None,
      oa_code: None,
    });
  }

  // dump cluster populations HERE
  // println!("------");
  // new_centroids.iter().for_each(|x| {
  //   println!("{}", x.population);
  // });

  (new_grid, calculate_scale_factors(&new_centroids, alpha, beta))
}