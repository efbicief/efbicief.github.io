use petgraph::graph::{UnGraph, NodeIndex};
use crate::utils::{std_dev, std_dev_ref};
use crate::mcmc::{PopNode, ClusterIndex};
use std::collections::{ HashMap, HashSet };
use rayon::prelude::*;

fn pops_by_cluster(graph: &UnGraph<PopNode, ()>) -> HashMap<i32, i32> {
  let mut pop_dist: HashMap<i32, i32> = HashMap::new();
  graph.node_indices().for_each(|node_index| {
    let node_weight = graph.node_weight(node_index).unwrap();

    // Get cluster and population
    let cluster = node_weight.cluster;
    let population = node_weight.population;

    // Insert if not already present, add if one is present
    match pop_dist.get(&cluster) {
      Some(pop) => pop_dist.insert(cluster, pop + population),
      None => pop_dist.insert(cluster, population),
    };
  });
  pop_dist
}

fn augment_pops_by_cluster(pop_dist: &mut HashMap<i32, i32>, c_from: i32, c_to: i32, pop_diff: i32) {
  // Get current populations
  let pop_from = *pop_dist.get(&c_from).unwrap();
  let pop_to = *pop_dist.get(&c_to).unwrap();

  // Update populations
  pop_dist.insert(c_from, pop_from - pop_diff);
  pop_dist.insert(c_to, pop_to + pop_diff);
}

pub fn score_one_by_population(graph: &UnGraph<PopNode, ()>) -> f64 {
  let pop_dist = pops_by_cluster(graph);
  match std_dev_ref(&pop_dist.values().collect()) {
    Some(sd) => sd,
    None => panic!("Error calculating standard deviation"),
  }
}

pub fn opt_population(graph: &UnGraph<PopNode, ()>, swaps: &[(NodeIndex, ClusterIndex)]) -> Vec<(f64, (NodeIndex, ClusterIndex))> {
  // Collect populations by cluster
  let mut pop_dist = pops_by_cluster(graph);

  // print!("pop_dist: [");
  // for pop in pop_dist.values() {
  //   print!("{}, ", pop);
  // }
  // println!("]");

  match std_dev_ref(&pop_dist.values().collect()) {
    // Some(sd) => print!("Standard deviation: {}, ", sd as i32),
    Some(sd) => println!("{}", sd as i32),
    None => panic!("Error calculating standard deviation"),
  };

  // let sample: Vec<_> = swaps
  //     .choose_multiple(&mut rand::thread_rng(), 100)
  //     .collect();
  
  // Get the standard deviation for each potential swap
  swaps.iter().map(|(nindex, c_to)| { // par_iter
    // Get nindex weight cluster
    let nindex_weight = graph.node_weight(*nindex).unwrap();
    let nindex_cluster = nindex_weight.cluster;
    let nindex_pop = nindex_weight.population;

    // Augment to make the swap
    augment_pops_by_cluster(&mut pop_dist, nindex_cluster, *c_to, nindex_pop);

    // Score
    let score = match std_dev_ref(&pop_dist.values().collect()) {
      Some(sd) => sd,
      None => panic!("Error calculating standard deviation"),
    };

    // Unaugment
    augment_pops_by_cluster(&mut pop_dist, *c_to, nindex_cluster, nindex_pop);
    // Return
    (score, (*nindex, *c_to))
  }).collect()
}

pub fn calculate_centricity(graph: &UnGraph<PopNode, ()>, clusters: Option<HashSet<ClusterIndex>>) -> HashMap<ClusterIndex, f64> {
  // No normalisation needed - we will only ever consider relative scores in this metric
  // First: calculate (population) centres of each cluster
  // type: cluster -> (sum of xes * population, sum of ys * population, population)
  let mut centre_points_pop_weighted: HashMap<ClusterIndex, (f64, f64, f64)> = HashMap::new();
  for node_index in graph.node_indices() {
    let node_weight = graph.node_weight(node_index).unwrap();
    let cluster = node_weight.cluster;
    match clusters {
      None => (), // Do all by default if no clusters specified
      Some(ref clusters) => if !clusters.contains(&cluster) { continue; } // Skip if not in clusters
    }
    let population = node_weight.population as f64;
    let x = node_weight.x;
    let y = node_weight.y;

    // Insert if not already present, add if one is present
    match centre_points_pop_weighted.get(&cluster) {
      Some((sum_x, sum_y, pop)) => {
        centre_points_pop_weighted.insert(cluster, (sum_x + (x * population), sum_y + (y * population), pop + population));
      },
      None => {
        centre_points_pop_weighted.insert(cluster, (x * population, y * population, population));
      }
    };
  }

  // For each cluster, get the centre point
  let centre_points: HashMap<i32, (f64, f64)> = centre_points_pop_weighted.par_iter().map(|(cluster, (sum_x, sum_y, pop))| {
    (*cluster, (sum_x / pop, sum_y / pop))
  }).collect();

  // Now, for each cluster, calculate the distance from each point to the centre point
  let mut cluster_centricity: HashMap<ClusterIndex, f64> = HashMap::new();
  for node_index in graph.node_indices() {
    let node_weight = graph.node_weight(node_index).unwrap();
    let cluster = node_weight.cluster;
    match clusters {
      None => (), // Do all by default if no clusters specified
      Some(ref clusters) => if !clusters.contains(&cluster) { continue; } // Skip if not in clusters
    }
    // let population = node_weight.population as f64;
    let x = node_weight.x;
    let y = node_weight.y;

    // Get the centre point
    let (centre_x, centre_y) = centre_points.get(&cluster).unwrap();

    // Calculate the distance
    let distance = ((x - centre_x).powi(2) + (y - centre_y).powi(2)).sqrt();

    // Insert if not already present, add if one is present
    match cluster_centricity.get(&cluster) {
      Some(sum) => {
        cluster_centricity.insert(cluster, sum + (distance));// * population));
      },
      None => {
        cluster_centricity.insert(cluster, distance);// * population);
      }
    };
  }
  cluster_centricity
}

pub fn calculate_centricity_proposed_swap(graph: &UnGraph<PopNode, ()>, 
    clusters: Option<HashSet<ClusterIndex>>, swap: (NodeIndex, ClusterIndex)) -> HashMap<ClusterIndex, f64> {
  // No normalisation needed - we will only ever consider relative scores in this metric
  // First: calculate (population) centres of each cluster
  // type: cluster -> (sum of xes * population, sum of ys * population, population)
  let mut centre_points_pop_weighted: HashMap<ClusterIndex, (f64, f64, f64)> = HashMap::new();
  for node_index in graph.node_indices() {
    let node_weight = graph.node_weight(node_index).unwrap();
    let cluster = if swap.0 == node_index { swap.1 } else { node_weight.cluster };
    match clusters {
      None => (), // Do all by default if no clusters specified
      Some(ref clusters) => if !clusters.contains(&cluster) { continue; } // Skip if not in clusters
    }
    let population = node_weight.population as f64;
    let x = node_weight.x;
    let y = node_weight.y;

    // Insert if not already present, add if one is present
    match centre_points_pop_weighted.get(&cluster) {
      Some((sum_x, sum_y, pop)) => {
        centre_points_pop_weighted.insert(cluster, (sum_x + (x * population), sum_y + (y * population), pop + population));
      },
      None => {
        centre_points_pop_weighted.insert(cluster, (x * population, y * population, population));
      }
    };
  }

  // For each cluster, get the centre point
  let centre_points: HashMap<i32, (f64, f64)> = centre_points_pop_weighted.par_iter().map(|(cluster, (sum_x, sum_y, pop))| {
    (*cluster, (sum_x / pop, sum_y / pop))
  }).collect();

  // Now, for each cluster, calculate the distance from each point to the centre point
  let mut cluster_centricity: HashMap<ClusterIndex, f64> = HashMap::new();
  for node_index in graph.node_indices() {
    let node_weight = graph.node_weight(node_index).unwrap();
    let cluster = if swap.0 == node_index { swap.1 } else { node_weight.cluster };
    match clusters {
      None => (), // Do all by default if no clusters specified
      Some(ref clusters) => if !clusters.contains(&cluster) { continue; } // Skip if not in clusters
    }
    // let population = node_weight.population as f64;
    let x = node_weight.x;
    let y = node_weight.y;

    // Get the centre point
    let (centre_x, centre_y) = centre_points.get(&cluster).unwrap();

    // Calculate the distance
    let distance = ((x - centre_x).powi(2) + (y - centre_y).powi(2)).sqrt();

    // Insert if not already present, add if one is present
    match cluster_centricity.get(&cluster) {
      Some(sum) => {
        cluster_centricity.insert(cluster, sum + (distance));// * population));
      },
      None => {
        cluster_centricity.insert(cluster, distance);// * population);
      }
    };
  }
  cluster_centricity
}
