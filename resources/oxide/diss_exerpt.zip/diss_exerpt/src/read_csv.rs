use std::error::Error;
use std::fs::File;
use std::ffi::OsString;
use std::collections::HashMap;
use proj::Coord;
use num::Float;

use crate::utils;

/* Modified from https://docs.rs/csv/latest/csv/tutorial/index.html */

pub fn read_population(file_path: OsString) -> Result<HashMap<String, i32>, Box<dyn Error>> {
  let file = File::open(file_path)?;
  let mut rdr = csv::Reader::from_reader(file);
  let mut pop_data: HashMap<String, i32> = HashMap::new();

  let mut this_pop: i32 = -1;
  for result in rdr.records() {
    let record = result?;
    if this_pop == -1 {
      this_pop = record[4].parse::<i32>().unwrap();
    } else {
      pop_data.insert(
        record[0].parse::<String>().unwrap(),
        this_pop + 1 + record[4].parse::<i32>().unwrap(),
      );
      this_pop = -1;
    }
  }
  Ok(pop_data)
}

pub fn read_output_area(file_path: OsString) -> Result<Vec<utils::OutputArea>, Box<dyn Error>> {
  let file = File::open(file_path)?;
  let mut rdr = csv::Reader::from_reader(file);
  let mut output_areas: Vec<utils::OutputArea> = Vec::new();

  for result in rdr.records() {
    let record = result?;
    output_areas.push(utils::OutputArea {
      area_code: record[3].parse::<String>().unwrap(),
      population: -1,
      latitude: record[1].parse::<f64>().unwrap(),
      longitude: record[2].parse::<f64>().unwrap(),
      post_code: record[0].parse::<String>().unwrap(),
      lsoa_name: record[5].parse::<String>().unwrap(),
      ltla_name: record[9].parse::<String>().unwrap(),
      pcon_name: "".to_owned(),
    });
  }
  Ok(output_areas)
}

pub fn read_file(file_path: OsString) -> Result<Vec<utils::Location>, Box<dyn Error>> {
  let file = File::open(file_path)?;
  let mut rdr = csv::Reader::from_reader(file);
  let mut unnormalised: Vec<utils::Location> = Vec::new();

  for result in rdr.records() {
    let record = result?;
    unnormalised.push(utils::Location {
      x: record[0].parse::<f64>().unwrap(),
      y: record[1].parse::<f64>().unwrap(),
    });
  }
  Ok(unnormalised)
}

pub fn normalise_locs(mut locs: Vec<utils::OutputArea>, x_width: f64, y_width: f64)
    -> Vec<utils::OutputArea>
    // where
    //   f64: Float + std::fmt::Debug + rand_distr::weighted_alias::AliasableWeight,
    {
  // get bounds of x and y
  let mut x_bounds = (f64::MIN, f64::MAX);
  let mut y_bounds = (f64::MIN, f64::MAX);

  for loc in &locs {
    if loc.x() > x_bounds.0 {
      x_bounds.0 = loc.x();
    } else if loc.x() < x_bounds.1 {
      x_bounds.1 = loc.x();
    }
    if loc.y() > y_bounds.0 {
      y_bounds.0 = loc.y();
    } else if loc.y() < y_bounds.1 {
      y_bounds.1 = loc.y();
    }
  }

  let x_multiplier = x_width / (x_bounds.0 - x_bounds.1);
  let y_multiplier = y_width / (y_bounds.0 - y_bounds.1);

  // Select lowest multiplier to retain aspect ratio
  let multiplier = if x_multiplier < y_multiplier {
    x_multiplier
  } else {
    y_multiplier
  };

  // normalise
  for loc in &mut locs {
    loc.longitude = (loc.x() - x_bounds.1) * multiplier;
    loc.latitude = (loc.y() - y_bounds.1) * multiplier;
  }
  locs
}
