use raylib::prelude::*;

pub fn start_raylib() -> (RaylibHandle, RaylibThread) {
  // instantiate window dimensions
  let screensize = 930;
  let coordwidth = 2;
  let gsize = (screensize / coordwidth) as usize;

  // Start raylib
  let (mut rl, thread) = raylib::init()
      .size(screensize, screensize)
      .title("Election boundary generator")
      .build();

  rl.set_target_fps(60);

  // Placeholder text
  rl.begin_drawing(&thread)
    .draw_text("Loading...", 12, 12, 20, Color::GRAY);

  (rl, thread)
}