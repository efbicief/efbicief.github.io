use petgraph::graph::{UnGraph, NodeIndex};
use crate::kmeans::Coord;
use crate::scorers::{ opt_population, score_one_by_population, calculate_centricity, calculate_centricity_proposed_swap };
use std::collections::{ HashMap, HashSet };
use rand::prelude::SliceRandom;
use std::slice;
// use rayon::prelude::*;

pub type ClusterIndex = i32;

#[derive(Debug)]
pub struct GraphData {
  graph: UnGraph<PopNode, ()>,
  swaps: Vec<(NodeIndex, ClusterIndex)>,
  cluster_neighbours: HashMap<ClusterIndex, i32>,
  centricities: HashMap<ClusterIndex, f64>,
  temperature: f64,
}

#[derive(Debug)]
pub struct EdgeData {
  pub start: String,
  pub end: String,
}

#[derive(Debug, Clone)]
pub struct PopNode {
  pub population: i32,
  pub cluster: ClusterIndex,
  pub oa_code: String,
  pub x: f64,
  pub y: f64,
}

fn get_potential_swaps(graph: &UnGraph<PopNode, ()>) -> Vec<(NodeIndex, ClusterIndex)> {
  let mut swaps: Vec<(NodeIndex, ClusterIndex)> = Vec::new();

  for node in graph.node_indices() {
    let node_cluster = graph.node_weight(node).unwrap().cluster;
    graph.neighbors(node).for_each(|neighbour| {
      let neighbour_cluster = graph.node_weight(neighbour).unwrap().cluster;
      if neighbour_cluster != node_cluster {
        swaps.push((node, neighbour_cluster));
      }
    });
  }
  swaps
}

fn get_cluster_neighbour_amounts(graph: &UnGraph<PopNode, ()>) -> HashMap<ClusterIndex, i32> {
  let mut cluster_neighbour_amounts: HashMap<ClusterIndex, i32> = HashMap::new();

  // Get neighbours of each node
  for node in graph.node_indices() {
    let node_cluster = graph.node_weight(node).unwrap().cluster;
    let mut cluster_neighbour_amount = 0;
    // Check against neighbours' clusters
    graph.neighbors(node).for_each(|neighbour| {
      let neighbour_cluster = graph.node_weight(neighbour).unwrap().cluster;
      if neighbour_cluster != node_cluster { // If neighbour is in a different cluster
        cluster_neighbour_amount += 1;
      }
    });
    // Add at the end
    cluster_neighbour_amounts.insert(node_cluster, cluster_neighbour_amount);
  }

  // Return
  // println!("{:?}", cluster_neighbour_amounts);
  cluster_neighbour_amounts
}

pub fn convert_coord_grid(grid: &Vec<Coord>, edges: &[EdgeData]) 
      -> (UnGraph<PopNode, ()>, Vec<(NodeIndex, ClusterIndex)>, HashMap<ClusterIndex, i32>) {
  println!("Converting grid!");
  let mut graph = UnGraph::<PopNode, ()>::new_undirected();
  let mut nodes: HashMap<String, NodeIndex> = HashMap::new();
  for coord in grid {
    nodes.insert(coord.oa_code.clone().unwrap(), graph.add_node(PopNode {
      population: coord.population,
      cluster: coord.cluster,
      oa_code: coord.oa_code.clone().unwrap(),
      x: coord.x,
      y: coord.y,
    }));
  }

  let mut invalid_count = 0;
  edges.iter().for_each(|edge| {
    if nodes.get(&edge.start).is_some() {
      if nodes.get(&edge.end).is_some() {
        graph.update_edge(nodes[&edge.start], nodes[&edge.end], ());
      } else { invalid_count += 1; }
    } else { invalid_count += 1; }
  });

  println!("Graph has {} nodes and {} edges ({} invalid nodes referenced in edges)", graph.node_count(), graph.edge_count(), invalid_count);

  let swaps = get_potential_swaps(&graph);
  let cluster_neighbour_amounts = get_cluster_neighbour_amounts(&graph);
  (graph, swaps, cluster_neighbour_amounts)
}

fn check_swap_keeps_connectivity(nindex: NodeIndex, graph: &UnGraph<PopNode, ()>) -> bool {
  // Get cluster that nindex is originally
  let original_cluster = graph.node_weight(nindex).unwrap().cluster;

  // Perform dfs from nindex, and check that all nodes in original cluster are still connected
  let mut visited: Vec<NodeIndex> = Vec::new();
  let mut stack: Vec<NodeIndex> = Vec::new();
  stack.push(nindex);
  while !stack.is_empty() {
    let this_node = stack.pop().unwrap();
    if !visited.contains(&this_node) {
      visited.push(this_node);
      graph.neighbors(this_node).for_each(|neighbour| {
        if graph.node_weight(neighbour).unwrap().cluster == original_cluster {
          stack.push(neighbour);
        }
      });
    }
  }
  let original_size = visited.len();

  // Perform another dfs, ignoring nindex (since it will be swapped)
  // Start from any neighbour of nindex with the same cluster
  let mut visited: Vec<NodeIndex> = Vec::new();
  let mut stack: Vec<NodeIndex> = Vec::new();
  let start = graph.neighbors(nindex).find(|neighbour| {
    graph.node_weight(*neighbour).unwrap().cluster == original_cluster
  });
  match start {
    Some(s) => stack.push(s),
    None => return false,
  }
  while !stack.is_empty() {
    let this_node = stack.pop().unwrap();
    if !visited.contains(&this_node) && this_node != nindex { // ignoring nindex
      visited.push(this_node);
      graph.neighbors(this_node).for_each(|neighbour| {
        if graph.node_weight(neighbour).unwrap().cluster == original_cluster {
          stack.push(neighbour);
        }
      });
    }
  }
  let mod_size = visited.len();

  // Compare sizes and return
  // println!("Modified: {}, original: {}", mod_size, original_size);
  mod_size == original_size - 1
}

fn check_swap_still_valid(nindex: NodeIndex, graph: &UnGraph<PopNode, ()>, changed_nindices: &[NodeIndex]) -> bool {
  // check if nindex has no neighbours that have been changed
  // && make sure that swapping wouldn't split a cluster in twain
  graph.neighbors(nindex).any(|neighbour| {
    !changed_nindices.contains(&neighbour)
  }) && check_swap_keeps_connectivity(nindex, graph)
}

fn calculate_neighbours_scale_factors(graph: &UnGraph<PopNode, ()>, cluster_neighbours: &HashMap<ClusterIndex, i32>) -> HashMap<ClusterIndex, f64> {
  // score = 1 / (cluster_neighbours / sqrt(num_nodes))
  // Get the number of nodes in each cluster
  let mut cluster_sizes: HashMap<ClusterIndex, i32> = HashMap::new();
  for node in graph.node_indices() {
    let cluster = graph.node_weight(node).unwrap().cluster;
    let entry = cluster_sizes.entry(cluster).or_insert(0);
    *entry += 1;
  }
  // map to 1 / (cluster_neighbours / sqrt(num_nodes)) and return
  let mut scale_factors: HashMap<ClusterIndex, f64> = HashMap::new();
  for (cluster, neighbours) in cluster_neighbours {
    let size = cluster_sizes.get(cluster).unwrap();
    let scale_factor = *neighbours as f64 / (*size as f64).sqrt();
    scale_factors.insert(*cluster, scale_factor);
  }
  scale_factors
}

fn calculate_simulated_annealing(proposed_h: f64, current_h: f64, temperature: f64) -> bool {
  let prob_accept = (-(proposed_h - current_h) / temperature).exp(); // no -, since minimising?
  let rand = rand::random::<f64>();
  // println!("p(accept) = {}, rand = {}, diff = {}", prob_accept, rand, proposed_h - current_h);
  rand < prob_accept
}

fn calculate_softmax(possible_scores: &Vec<(f64, (NodeIndex, i32))>, temperature: f64) -> Vec<(f64, (NodeIndex, i32))> {
  let mut total = 0.0;
  // println!("swapno: {:?}", possible_scores.len());
  for (score, _) in possible_scores {
    total += (-score / temperature).exp(); // check the - here
  }
  total /= 100.0; // changable
  
  let mut filtered_scores: Vec<(f64, (NodeIndex, i32))> = Vec::new();
  possible_scores.iter().for_each(|(score, swap)| {
    let prob = (-score / temperature).exp() / total;
    let rand = rand::random::<f64>();
    // println!("score:{}, temp:{}, total:{}, Prob of accept = {}", score, temperature, total, prob);
    if rand < prob { filtered_scores.push((*score, *swap)); }
  });
  // println!("{:?}", possible_scores);
  filtered_scores
}

fn iterate_graph(graph: &UnGraph<PopNode, ()>, p_swaps: &Vec<(NodeIndex, ClusterIndex)>,
      cluster_neighbours: &HashMap<ClusterIndex, i32>, temperature: &mut f64,
      centricities: &HashMap<i32, f64>, improve_centricity: bool)
      -> Vec<(f64, (NodeIndex, ClusterIndex))> {
  // Calculate current score and score for each swap
  let current_score = score_one_by_population(graph);
  let mut possible_scores = opt_population(graph, p_swaps);
  // choose random possible swap
  // let single_swap = p_swaps.choose(&mut rand::thread_rng()).unwrap();
  // let mut possible_scores = opt_population(graph, slice::from_ref(single_swap));

  // Calculate scale factors from cluster_neighbours (note: old roundness metric no longer in use)
  // let scale_factors = calculate_neighbours_scale_factors(graph, cluster_neighbours);
  
  // Scale with cluster neighbours s.f.
  // possible_scores.iter_mut().for_each(|(score, (nindex, _))| {
  //   let cluster = graph.node_weight(*nindex).unwrap().cluster;
  //   *score *= scale_factors.get(&cluster).unwrap() + 0.5;
  // });

  possible_scores.iter_mut().for_each(|(score, _)| {
    *score -= current_score;
  });

  // Remove swaps probabilistically with softmax
  let prev_size = possible_scores.len();
  // possible_scores.retain(|(this_score, _)| {
  //   calculate_simulated_annealing(*this_score, current_score, *temperature)
  // });
  possible_scores = calculate_softmax(&possible_scores, *temperature);

  // let anneal_size = possible_scores.len();
  // print!("{} swaps of {} ({}%) after softmax (temperature = {}); ", anneal_size, prev_size, 100.0 * possible_scores.len() as f32 / prev_size as f32, temperature);

  possible_scores.sort_unstable_by(|(s1, _), (s2, _)| s1.partial_cmp(s2).unwrap()); // time consuming?

  // Check that swaps are valid simultaneously, filter invalid ones
  let mut changed_nindices: Vec<NodeIndex> = Vec::new();
  possible_scores.retain(|(_, (nindex, cindex))| {
    if changed_nindices.len() < 10 && check_swap_still_valid(*nindex, graph, &changed_nindices) { // changable
      let centricity_okay = if improve_centricity {
        // get centricities with proposed swap
        let nindex_cluster = graph.node_weight(*nindex).unwrap().cluster;
        let clusters_to_get: HashSet<ClusterIndex> = vec![nindex_cluster, *cindex].into_iter().collect();
        let proposed_centricities = calculate_centricity_proposed_swap(graph, Some(clusters_to_get), (*nindex, *cindex));
        // see how different the centricities are, note that a negative difference is good!
        let centricity_diff = (proposed_centricities.get(&nindex_cluster).unwrap() - centricities.get(&nindex_cluster).unwrap())
            + (proposed_centricities.get(cindex).unwrap() - centricities.get(cindex).unwrap());
        if centricity_diff > 0.0 { false } else { changed_nindices.push(*nindex); true }
      } else { changed_nindices.push(*nindex); true };
      // .. if either we don't care, or centricity is good ..
      centricity_okay
    } else { false }
  });
  // println!("{} swaps after checking validity (impr.centricity = {})", possible_scores.len(), improve_centricity);

  // Get best (lowest standard deviation) iteration + worst
  // println!("Valid changes: {}, {:?}", possible_scores.len(), if !possible_scores.is_empty() { possible_scores[0].0 } else { -1.0 });

  // return
  *temperature *= 0.999;
  possible_scores
}

pub fn perform_best_swap(grid: &mut Vec<Coord>, edges: &[EdgeData], graph_data: Option<GraphData>, improve_centricity: bool) -> GraphData {
  // See if graphdata defined, and define it if not
  let this_graph_data = match graph_data {
    None => {
      let (graph, swaps, cluster_neighbours) = convert_coord_grid(grid, edges);
      let centricities = calculate_centricity(&graph, None);
      GraphData { graph, swaps, cluster_neighbours, centricities, temperature: 10000.0 }
    },
    Some(gd) => gd,
  };

  let mut graph = this_graph_data.graph;
  let swaps = &this_graph_data.swaps;
  let cluster_neighbours = &this_graph_data.cluster_neighbours;
  let centricities = &this_graph_data.centricities;
  let mut temperature = this_graph_data.temperature;

  // Print centricities for logging
  // println!("Centricities: {:?}", centricities);

  let chosen_swaps = iterate_graph(&graph, swaps, cluster_neighbours, &mut temperature, centricities, improve_centricity);

  for (_, this_swap) in chosen_swaps {
    // get info of node/grid entry to change
    let node = graph.node_weight(this_swap.0).unwrap().clone();

    // modify graph entry
    let mut graph_entry = graph.node_weight_mut(this_swap.0).unwrap();
    graph_entry.cluster = this_swap.1;

    // See if centricity has been improved
    let to_calculate_centricity: HashSet<ClusterIndex> = vec![node.cluster, this_swap.1].into_iter().collect();
    let centricity_updated = calculate_centricity(&graph, Some(to_calculate_centricity.clone()));
    // println!("New centricities for: {:?}", to_calculate_centricity.clone());
    let mut overall_centricity_change = 0.0;
    for cindex in &[node.cluster, this_swap.1] {
      // println!("{} -> {} for {}", centricities.get(cindex).unwrap(), centricity_updated.get(cindex).unwrap(), cindex);
      overall_centricity_change += centricity_updated.get(cindex).unwrap() - centricities.get(cindex).unwrap();
      // centricity change is good if it is negative, i.e. it should be going down over time
    }

    // if overall_centricity_change < 0.0 {
    //   println!("Centricity changed by {}!", overall_centricity_change);
    // }

    // if improve_centricity {
    //   if overall_centricity_change < 0.0 {
    //     // println!("->Better\n");
    //     // modify grid entry in-place
    //     let mut grid_entry = grid.iter_mut()
    //       .find(|c| c.oa_code == Some(node.oa_code.clone())).unwrap();
    //     grid_entry.cluster = this_swap.1;
    //   } else {
    //     // println!("->Worse\n");
    //     // revert graph entry
    //     let mut graph_entry = graph.node_weight_mut(this_swap.0).unwrap();
    //     graph_entry.cluster = node.cluster;
    //   }
    // } else {
      // println!("->Doesn't matter\n");
      // modify grid entry in-place
    let mut grid_entry = grid.iter_mut()
      .find(|c| c.oa_code == Some(node.oa_code.clone())).unwrap();
    grid_entry.cluster = this_swap.1;
    // }

  }

  // regererate swaps and cluster neighbours
  let new_swaps = get_potential_swaps(&graph); // might take time
  let new_cluster_neighbours = get_cluster_neighbour_amounts(&graph); // as might this
  let new_centricities = calculate_centricity(&graph, None); // and this!

  // return new graph data
  GraphData { 
    graph,
    swaps: new_swaps,
    cluster_neighbours: new_cluster_neighbours,
    centricities: new_centricities,
    temperature,
  }
}
