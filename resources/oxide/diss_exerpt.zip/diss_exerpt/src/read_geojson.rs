use std::fs;
use std::ffi::OsString;

use geojson::GeoJson;

pub fn read_file(fname: OsString) -> GeoJson {
  fs::read_to_string(fname).unwrap().parse::<GeoJson>().unwrap()
}