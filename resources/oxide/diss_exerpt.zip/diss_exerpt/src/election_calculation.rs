use std::collections::HashMap;
use std::ops::Add;
use itertools::Itertools;
use crate::kmeans::Coord;

#[derive(Default, Copy, Clone, Debug)]
pub struct EngResult2019 {
  pub turnout: i32,
  pub con: i32,
  pub lab: i32,
  pub ld: i32,
  pub brexit: i32,
  pub green: i32,
  pub pc: i32,
  pub other: i32,
  pub other_winner: i32,
}

#[derive(Default, Copy, Clone, Debug)]
struct EngOAResult2019 {
  pub population: i32,
  pub divisor: Option<f64>,
  pub result: EngResult2019,
}

impl Add for EngResult2019 {
  type Output = Self;
  fn add(self, rhs: Self) -> Self {
      Self {
          turnout: self.turnout + rhs.turnout,
          con: self.con + rhs.con,
          lab: self.lab + rhs.lab,
          ld: self.ld + rhs.ld,
          brexit: self.brexit + rhs.brexit,
          green: self.green + rhs.green,
          pc: self.pc + rhs.pc,
          other: self.other + rhs.other,
          other_winner: self.other_winner + rhs.other_winner,
      }
  }
}

impl Add for EngOAResult2019 {
  type Output = Self;
  fn add(self, rhs: Self) -> Self {
      Self {
          population: self.population + rhs.population,
          divisor: self.divisor,
          result: self.result + rhs.result,
      }
  }
}

fn get_winner(result: &EngResult2019) -> String {
  let mut winner = "con".to_owned();
  let mut max = result.con;
  if result.lab > max {
    winner = "lab".to_owned();
    max = result.lab;
  }
  if result.ld > max {
    winner = "ld".to_owned();
    max = result.ld;
  }
  if result.brexit > max {
    winner = "brexit".to_owned();
    max = result.brexit;
  }
  if result.green > max {
    winner = "green".to_owned();
    max = result.green;
  }
  if result.pc > max {
    winner = "pc".to_owned();
    max = result.pc;
  }
  if result.other > max {
    winner = "other".to_owned();
    max = result.other;
  }
  if result.other_winner > max {
    winner = "other_winner".to_owned();
  }
  winner
}

pub fn calculate_election_result(electoral_data: &HashMap<String, EngResult2019>, grid: &[Coord]) {
  let mut results: HashMap<i32, EngOAResult2019> = HashMap::new(); // cluster number to result for cluster

  grid.iter().for_each(|g| {
    let this_result = match electoral_data.get(g.constituency_name.as_ref().unwrap()) {
      // None => EngResult2019::default(),
      None => {
        panic!("Matched nothing: {:?}", g.constituency_name.as_ref().unwrap());
      }
      Some(r) => *r,
    };
    match results.get(&(g.cluster)) {
      None => {
        results.insert(g.cluster, EngOAResult2019 {
          population: g.population,
          divisor: None,
          result: this_result,
        });
      },
      Some(prev_result) => {
        results.insert(g.cluster, *prev_result + EngOAResult2019 {
          population: g.population,
          divisor: None,
          result: this_result,
        });
      }
    }
  });

  // Calculate divisors for scaling results
  results.iter_mut().for_each(|(_,v)| {
    v.divisor = Some(v.result.turnout as f64 / v.population as f64);
  });

  // (v.result.con as f64 / div) / (v.result.turnout as f64 / div)
  //   // let div = v.divisor.unwrap();

  let victories: HashMap<String, i32> = results.iter()
    .map(|(_,v)| get_winner(&v.result))
    .fold( HashMap::new(), |mut acc, x| {
      *acc.entry(x).or_insert(0) += 1;
      acc
    }
  );
  
  // println!("{:?}", victories);
  // nicely print in order
  // print!("{{ ");
  // for (k, v) in victories.iter().sorted_by_key(|x| x.0) {
  //   print!("{}:, {},", k, v);
  // }
  // println!("}}");

}