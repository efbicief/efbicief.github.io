use postgres::{Client, NoTls, Row};

pub fn inst_client() -> Client {
  match Client::connect("postgresql://efbicief@localhost/cs310", NoTls) {
    Ok(inner) => inner,
    Err(e) => panic!("{}", e)
  }
}

fn query_client(cli: &mut Client, query: &str) -> Vec<Row> {
  match cli.query(query, &[]) {
    Err(e2) => {
      panic!("{}", e2);
    }
    Ok(rows) => rows
  }
}

pub fn query_population_data(cli: &mut Client) -> Vec<Row> {
  query_client(cli, 
    "SELECT \"Output Areas\", SUM(\"Observation\") \
    FROM public.oa_pop \
    GROUP BY \"Output Areas\" \
    ORDER BY \"Output Areas\" ASC;"
  )
}

pub fn query_oa_data(cli: &mut Client) -> Vec<Row> {
  query_client(cli, 
    "SELECT pcd, gridgb1e, gridgb1n, oa21cd, lsoa21nm, ltla22nm FROM public.postcode_oas \
    WHERE oa21cd<>'' \
    ORDER BY oa21cd ASC;"
  )
}

pub fn query_population_oa_data(cli: &mut Client) -> Vec<Row> {
  // Also includes constituency name
  query_client(cli, 
    "WITH first_row AS (
      SELECT ROW_NUMBER()
      OVER (PARTITION BY oa21cd) AS rownum, pcd, gridgb1e, gridgb1n, oa21cd, lsoa21nm, ltla22nm, sum
      FROM (
        SELECT pcd, gridgb1e, gridgb1n, oa21cd, lsoa21nm, ltla22nm, sum
        FROM (
          SELECT pcd, gridgb1e, gridgb1n, oa21cd, lsoa21nm, ltla22nm
          FROM public.postcode_oas
          WHERE oa21cd<>''
        ) s1
        INNER JOIN (
          SELECT \"Output Areas\", SUM(\"Observation\")
          FROM public.oa_pop
          GROUP BY \"Output Areas\"
        ) s2
        ON s1.oa21cd = s2.\"Output Areas\"
        ORDER BY oa21cd ASC
      ) foo
    )
    
    SELECT pcd, gridgb1e, gridgb1n, oa21cd, lsoa21nm, ltla22nm, sum, LOWER(\"PCON21NM\") AS \"PCON21NM\"
    FROM first_row
    INNER JOIN (
      SELECT \"LSOA21NM\", \"PCON21NM\"
      FROM public.lsoa_pcon
    ) s3
    ON first_row.lsoa21nm = s3.\"LSOA21NM\"
    WHERE rownum = 1;"
  )
}

pub fn query_electoral_data(cli: &mut Client) -> Vec<Row> {
  // 100 * CAST(valid_votes as FLOAT) / electorate AS turnout,
  query_client(cli,
    "SELECT LOWER(constituency_name) AS constituency_name, 
    valid_votes AS turnout,
    con, lab, ld, brexit, green, pc, other, other_winner
    FROM public.\"GE2019\""
  )
}

pub fn query_oa_neighbours_data(cli: &mut Client) -> Vec<Row> {
  query_client(cli,
    "SELECT * FROM public.oa_neighbours"
  )
}