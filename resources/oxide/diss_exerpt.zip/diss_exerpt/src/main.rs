// #![feature(thread_local)]

mod utils;
mod kmeans;
mod read_csv;
mod read_geojson;
mod pg_interface;
mod data_processors;
mod election_calculation;
mod mcmc;
mod scorers;
mod visualisation;

use std::collections::HashMap;
use raylib::prelude::*;
use rand::Rng;
use rand::seq::SliceRandom;
use rand_distr::{Normal, Distribution};
use voronoi::{Point, voronoi, make_polygons};
use petgraph::graph::{UnGraph, NodeIndex};
use mcmc::{PopNode, ClusterIndex};
// use geojson::{Feature, GeoJson, Geometry, Value};

fn calc_grid_coord(mouse_x: i32, mouse_y: i32, coordinate_width: i32) -> (i32, i32) {
  ((mouse_x/coordinate_width), (mouse_y/coordinate_width))
}

fn iterate_kmeans(grid: &Vec<kmeans::Coord>, centroids: &Vec<kmeans::Coord>, 
      electoral_data: &HashMap<String, election_calculation::EngResult2019>,
      output_area_neighbour_data: &Vec<mcmc::EdgeData> ) -> (Vec<kmeans::Coord>, Vec<kmeans::Coord>) {
  // iterate a step, terminate when no change
  let alpha = 0.75;
  let beta = 0.5;
  let (new_grid, new_centroids) = kmeans::iterate_grid(grid, centroids, alpha, beta);

  // Calculate election results
  election_calculation::calculate_election_result(electoral_data, &new_grid);

  // Get population distribution from centroids
  let mut pop_dist: Vec<i32> = Vec::new();
  // print!("pop_dist: [");
  // for pt in &new_centroids {
  //   pop_dist.push(pt.population);
  //   print!("{}, ", pt.population);
  // }
  // println!("]");

  // Get std_dev of population
  match utils::std_dev(&pop_dist) {
    Some(std_dev) => {
      println!("std_dev: {}", std_dev as i32);
    },
    None => {
      println!("Error calculating standard deviation");
    }
  }
  (new_grid, new_centroids)
}

fn main() {
  let mut closest_item_grid: Vec<(i32, i32, i32, usize)> = Vec::new();

  // Connect to db
  println!("Starting postgres client...");
  let mut pg_client = pg_interface::inst_client();

  println!("Fetching output area data...");
  let mut output_area_data = data_processors::proc_population_oa_data(
    pg_interface::query_population_oa_data(&mut pg_client)
  );

  // Print total population
  let pop_sum = output_area_data.iter().map(|x| x.population).sum::<i32>();
  println!("Total population (from structs): {}", pop_sum);
  println!("Loaded population data!");

  // Load electoral data
  println!("Loading electoral data...");
  let electoral_data = data_processors::proc_electoral_data(
    pg_interface::query_electoral_data(&mut pg_client)
  );
  println!("Loaded electoral data!");

  // instantiate window dimensions
  let screensize = 950;
  let coordwidth = 2;
  let gsize = (screensize / coordwidth) as usize;

  let mut scale = 1.0;
  let mut xoffset = 0;
  let mut yoffset = 0;

  // Instantiate grid
  let mut grid: Vec<kmeans::Coord> = Vec::new();
  let mut centroids: Vec<kmeans::Coord> = Vec::new();
  let mut colours: Vec<Color> = Vec::new();

  let mut mcmc_graph: Option<mcmc::GraphData> = None;

  // Normalise OA locations & push to grid
  println!("Normalising locations... (Total OAs: {})", output_area_data.len());
  output_area_data = read_csv::normalise_locs(output_area_data, gsize as f64, gsize as f64);
  for loc in output_area_data {
    grid.push( kmeans::Coord {
      x: loc.longitude,
      y: loc.latitude,
      population: loc.population,
      cluster: 0,
      scale_factor: None,
      constituency_name: Some(loc.pcon_name),
      oa_code: Some(loc.area_code),
    });
  }
  println!("Finished normalising locations!");

  println!("Fetching output area neighbour data...");
  let output_area_neighbour_data = data_processors::proc_oa_neighbours_data(
    pg_interface::query_oa_neighbours_data(&mut pg_client)
  );

  // For each point in the screen area, find the index of the closest grid item.
  println!("Indexing closest grid items for boundary visualisation estimate, this may take a couple of minutes...");
  if closest_item_grid.is_empty() {
    for x in 0..gsize {
      let ptx = ((x as f64 * scale) as i32 * coordwidth) - yoffset;
      for y in 0..gsize {
        let pty = ((y as f64 * scale) as i32 * coordwidth) - xoffset;
        let mut closest_gitem = 0;
        let mut closest_distance = f64::MAX;
        for (c_index, c) in grid.iter().enumerate() {
          // let c = grid[c_index].clone();
          let dist = ((x as f64 - c.x).powi(2) + (y as f64 - c.y).powi(2)).sqrt();
          if dist < closest_distance {
            closest_distance = dist;
            closest_gitem = c_index;
          }
        }
        closest_item_grid.push((pty, screensize - ptx, coordwidth, closest_gitem));
      }
    }
  }

  // Start raylib
  let (mut raylib_handle, raylib_thread) = visualisation::start_raylib();

  let mut simactive = false;
  let mut improve_centricity = false;
  let mut iteration = 0;
  let mut k = 0;

  let mut phase = "kmeans";
  let mut rng = rand::thread_rng();

  // main loop
  while !raylib_handle.window_should_close() {
    let mut d = raylib_handle.begin_drawing(&raylib_thread);
    d.clear_background(Color::WHITE);

    // Information to draw on screen
    let to_draw_text = &format!("{:?}", calc_grid_coord(d.get_mouse_x(), d.get_mouse_y(), coordwidth));
    let iteration_text = &format!("Iteration {}", iteration);

    // handle presses
    if d.is_key_pressed(KeyboardKey::KEY_SPACE) { // start algorithm
      if colours.len() > 0 {
        simactive = !simactive;
      }
    } else if d.is_key_pressed(KeyboardKey::KEY_C) {
      improve_centricity = !improve_centricity;
    } else if d.is_key_pressed(KeyboardKey::KEY_UP) {
      yoffset += 100;
    } else if d.is_key_pressed(KeyboardKey::KEY_DOWN) {
      yoffset -= 100;
    } else if d.is_key_pressed(KeyboardKey::KEY_LEFT) {
      xoffset -= 100;
    } else if d.is_key_pressed(KeyboardKey::KEY_RIGHT) {
      xoffset += 100;
    } else if d.is_key_pressed(KeyboardKey::KEY_ZERO) {
      scale += 1.0;
    } else if d.is_key_pressed(KeyboardKey::KEY_NINE) && scale >= 2.0 {
      scale -= 1.0;
    } else if d.is_key_pressed(KeyboardKey::KEY_R) {
      centroids.clear();
      colours.clear();
      k = 0;
      simactive = false;
      improve_centricity = false;
      iteration = 0;
      phase = "kmeans"; 
      for c in grid.iter_mut() {
        c.cluster = 0;
        c.scale_factor = None;
      }

    } else if d.is_key_pressed(KeyboardKey::KEY_ENTER) { // Place centroid randomly
      for _ in 0..50 {
        // Choose random position from grid entries
        let coord_x;
        let coord_y;
        match grid.choose(&mut rand::thread_rng()) {
          Some(grid_item) => {
            coord_x = grid_item.x;
            coord_y = grid_item.y;
          },
          None => {
            coord_x = rng.gen_range(0..(screensize/coordwidth)) as f64;
            coord_y = rng.gen_range(0..(screensize/coordwidth)) as f64;
          }
        }
        centroids.push(kmeans::Coord {
          x: coord_x,
          y: coord_y,
          population: 0,
          cluster: k,
          scale_factor: Some(1.0 / (k as f64)), // Initialise to 1/k for weighted kmeans
          constituency_name: None,
          oa_code: None,
        });
        colours.push(utils::make_transparent(Color {
          r: rng.gen_range(1..15)*10,
          g: rng.gen_range(1..15)*10,
          b: rng.gen_range(1..15)*10,
          a: 255,
        }));
        k += 1;
      }
    }

    // start with k-means
    if phase == "kmeans" && simactive {
      (grid, centroids) = iterate_kmeans(&grid, &centroids, &electoral_data, &output_area_neighbour_data);
      iteration += 1;

      for pt in &centroids {
        let ptx = pt.x as i32 * coordwidth;
        let pty = pt.y as i32 * coordwidth;
        let colourindex: usize = pt.cluster as usize;
        d.draw_rectangle(pty, screensize - ptx, coordwidth*2, coordwidth*2, colours[colourindex]);
      }
  
      if !centroids.is_empty() {
        let mut points_vec: Vec<Point> = Vec::new();
        for pt in &centroids {
          let ptx = pt.x as i32 * coordwidth;
          let pty = pt.y as i32 * coordwidth;
          points_vec.push(Point {
            x: ordered_float::OrderedFloat(pty as f64),
            y: ordered_float::OrderedFloat((screensize - ptx) as f64),
          });
        }
  
        // draw voronoi
        let to_plot = &voronoi(points_vec, screensize as f64);
        let polys = make_polygons(to_plot);
        for i in 0..polys.len()-1 {
          let mut drawable_points: Vec<Vector2> = Vec::new();
          for p in &polys[i] {
            drawable_points.push(Vector2 {
              x: p.x.into_inner() as f32,
              y: p.y.into_inner() as f32,
            });
          }
          let last = &polys[i][0];
          drawable_points.push(Vector2 {
            x: last.x.into_inner() as f32,
            y: last.y.into_inner() as f32,
          });
          d.draw_line_strip(&drawable_points, Color::BLACK);
        }
      }

      if iteration == 51 {
        phase = "mcmc";
        simactive = !simactive;
      }
    } else if phase == "mcmc" && simactive {
      // Iterate mcmc graph, or create on first go
      mcmc_graph = Some(mcmc::perform_best_swap(&mut grid, &output_area_neighbour_data, mcmc_graph, improve_centricity));
      if iteration % 50 == 0 {
        election_calculation::calculate_election_result(&electoral_data, &grid);
      }
      iteration += 1;
    }

    // For each point in the screen area, find the closest grid item and draw the bg as the same colour.
    if !colours.is_empty() {
      for (pty, ptx, cw, closest_gitem) in &closest_item_grid {
        let grid_item_cluster = grid[*closest_gitem].cluster as usize;
        d.draw_rectangle(*pty, *ptx, *cw, *cw, utils::make_thin(colours[grid_item_cluster]));
      }
    }

    //draw grid
    for pt in &grid {
      let ptx = ((pt.x * scale) as i32 * coordwidth) - yoffset;
      let pty = ((pt.y * scale) as i32 * coordwidth) - xoffset;
      if k > 0 {
        let colourindex: usize = pt.cluster as usize;
        // Modified to draw the right way
        d.draw_rectangle(pty, screensize - ptx, coordwidth, coordwidth, colours[colourindex]);
      } else {
        d.draw_rectangle(pty, screensize - ptx, coordwidth, coordwidth, utils::make_transparent(Color::GRAY));
      }
    }

    // draw mouse position to screen
    d.draw_text(iteration_text, 12, 12, 20, Color::BLACK);
    d.draw_text(to_draw_text, 12, 40, 20, Color::BLACK);
    // if !colours.is_empty() {
    //   let k_text = &format!("k = {}", centroids.len());
    //   d.draw_text(k_text, 12, 60, 12, Color::GRAY);
    // }
    if improve_centricity {
      d.draw_text("Improving centricity", 12, 80, 12, Color::RED);
    }
  }
}