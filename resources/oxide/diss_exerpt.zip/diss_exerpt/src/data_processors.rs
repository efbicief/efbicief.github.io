use crate::utils::OutputArea;
use crate::election_calculation::EngResult2019;
use crate::mcmc::EdgeData;
use std::collections::HashMap;
use postgres::Row;

pub fn proc_population_data(rows: Vec<Row>) -> HashMap<String, i32> {
  rows.iter().map(|row| {
    (row.get("Output Areas"), row.get::<_,i64>("sum") as i32)
  }).collect()
}

pub fn proc_oa_data(rows: Vec<Row>) -> Vec<OutputArea> {
  rows.iter().map(|row| {
    OutputArea {
      area_code: row.get("oa21cd"),
      population: -1,
      latitude: row.get::<_,i32>("gridgb1e") as f64,
      longitude: row.get::<_,i32>("gridgb1n") as f64,
      post_code: row.get("pcd"),
      lsoa_name: row.get("lsoa21nm"),
      ltla_name: row.get("ltla22nm"),
      pcon_name: "".to_owned(),
    }
  }).collect()
}

pub fn proc_population_oa_data(rows: Vec<Row>) -> Vec<OutputArea> {
  rows.iter().map(|row| {
    OutputArea {
      area_code: row.get("oa21cd"),
      population: row.get::<_,i64>("sum") as i32,
      latitude: row.get::<_,i32>("gridgb1e") as f64,
      longitude: row.get::<_,i32>("gridgb1n") as f64,
      post_code: row.get("pcd"),
      lsoa_name: row.get("lsoa21nm"),
      ltla_name: row.get("ltla22nm"),
      pcon_name: row.get("PCON21NM"),
    }
  })
  // .filter(|oa| {
  //   oa.latitude > 500000.0 && oa.latitude < 560000.0 && oa.longitude > 150000.0 && oa.longitude < 200000.0
  // }) // uncomment to include london-only(ish) data
  .collect()
}

pub fn proc_electoral_data(rows: Vec<Row>) -> HashMap<String, EngResult2019> {
  rows.iter().map(|row| {
    (
      row.get("constituency_name"),
      EngResult2019 {
        turnout: row.get("turnout"),
        con: row.get("con"),
        lab: row.get("lab"),
        ld: row.get("ld"),
        brexit: row.get("brexit"),
        green: row.get("green"),
        pc: row.get("pc"),
        other: row.get("other"),
        other_winner: row.get("other_winner"),
      }
    )
  }).collect()
}

pub fn proc_oa_neighbours_data(rows: Vec<Row>) -> Vec<EdgeData> {
  rows.iter().map(|row| {
    EdgeData {
      start: row.get("oa21cd_1"),
      end: row.get("oa21cd_2"),
    }
  }).collect()
}