use std::ffi::OsString;
use std::env;
use std::error::Error;
use proj::{Proj, Coord};
use raylib::prelude::Color;

#[derive(Debug)]
pub struct Location {
  pub x: f64,
  pub y: f64,
}

impl Coord<f64> for Location {
  fn x(&self) -> f64 {
    self.x
  }
  fn y(&self) -> f64 {
    self.y
  }
  fn from_xy(x: f64, y: f64) -> Self {
    Location { x, y }
  }
}

// #[derive(Default, Clone, Debug, Hash)]
#[derive(Debug, Clone)]
pub struct OutputArea {
  pub area_code: String,
  pub population: i32,
  pub latitude: f64,
  pub longitude: f64,
  pub post_code: String,
  pub lsoa_name: String,
  pub ltla_name: String,
  pub pcon_name: String,
}

impl Coord<f64> for OutputArea {
  fn x(&self) -> f64 {
    self.longitude
  }
  fn y(&self) -> f64 {
    self.latitude
  }
  fn from_xy(x: f64, y: f64) -> Self {
    OutputArea {
      area_code: "".to_string(),
      population: -1,
      latitude: y,
      longitude: x,
      post_code: "".to_string(),
      lsoa_name: "".to_string(),
      ltla_name: "".to_string(),
      pcon_name: "".to_string(),
    }
  }
}

/// Returns the nth positional argument sent to this process. If there are not
/// n positional arguments, then this returns an error.
/// Indexing starts at 0!
pub fn get_nth_arg(n: usize) -> Result<OsString, Box<dyn Error>> {
  match env::args_os().nth(n) {
    None => Err(From::from(format!("expected {} arguments, but got none", n))),
    Some(file_path) => Ok(file_path),
  }
}

/// Converts northings and eastings to latitude and longitude
pub fn convert_eastings_northings(oa: OutputArea) -> OutputArea {
  // Set up a projection for converting northings and eastings to latitude and longitude
  // https://epsg.io/27700 to https://epsg.io/4326
  let from = "EPSG:27700";
  let to = "EPSG:4326";

  // Convert the northings and eastings to latitude and longitude
  let ref_proj = Proj::new_known_crs(&from, &to, None).unwrap();
  let result = ref_proj.convert(oa).unwrap();

  // println!("Result: {:?}", result);
  result
}


/// Set colour transparency to 30 (of 255)
pub fn make_transparent(colour: Color) -> Color {
  Color {
    r: colour.r,
    g: colour.g,
    b: colour.b,
    a: 130,
  }
}

pub fn make_thin(colour: Color) -> Color {
  Color {
    r: colour.r + 90,
    g: colour.g + 90,
    b: colour.b + 90,
    a: 130,
  }
}


/// Statistics utils
pub fn mean(data: &Vec<i32>) -> f64 {
  let sum = data.iter().sum::<i32>() as f64;
  let count = data.len() as f64;
  sum / count
}

pub fn std_dev(data: &Vec<i32>) -> Option<f64> {
  let count = data.len();
  let data_mean = mean(data);
  if count > 0 {
    let variance = data.iter().map(|value| {
      let diff = data_mean - (*value as f64);
      diff * diff
    }).sum::<f64>() / count as f64;
    Some(variance.sqrt())
  } else {
    None
  }
}

pub fn mean_ref(data: &Vec<&i32>) -> f64 {
  let sum = data.iter().fold(0, |acc, x| acc + *x) as f64;
  let count = data.len() as f64;
  sum / count
}

pub fn std_dev_ref(data: &Vec<&i32>) -> Option<f64> {
  let count = data.len();
  let data_mean = mean_ref(data);
  if count > 0 {
    let variance = data.iter().map(|value| {
      let diff = data_mean - (**value as f64);
      diff * diff
    }).sum::<f64>() / count as f64;
    Some(variance.sqrt())
  } else {
    None
  }
}
